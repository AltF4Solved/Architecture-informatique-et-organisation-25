#include "simulator.h"
#include "program.h"
#include "registers.h"

// Include the instruction headers so we can use them:
#include "oriInstruction.h"
#include "addInstruction.h"
#include "subInstruction.h"
#include "brneInstruction.h"

void loadProgram(Program *program) {
    // Sample program:
    // 0: ori $1, $0, 12   -> $1 = 12
    // 1: ori $2, $0, 4    -> $2 = 4
    // 2: ori $3, $0, 1    -> $3 = 1
    // 3: add $4, $4, $1   -> $4 = $4 + $1
    // 4: sub $2, $2, $3   -> $2 = $2 - $3
    // 5: brne $2, $0, -3  -> If $2 != 0, branch to instruction 2 (PC + 1 - 3)
    program->appendInstruction(new OriInstruction(1, 0, 12));
    program->appendInstruction(new OriInstruction(2, 0, 4));
    program->appendInstruction(new OriInstruction(3, 0, 1));
    program->appendInstruction(new AddInstruction(4, 4, 1));
    program->appendInstruction(new SubInstruction(2, 2, 3));
    program->appendInstruction(new BrneInstruction(2, 0, -3));
}

int main(void) {
    Registers *registers = new Registers();
    Program *program = new Program();

    loadProgram(program);

    Simulator theSimulator(registers, program);
    theSimulator.ui();

    return 0;
}
