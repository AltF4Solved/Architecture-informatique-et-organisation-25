#include "instruction.h"

instruction::instruction()
{
    //ctor
}

instruction::~instruction()
{
    //dtor
}
